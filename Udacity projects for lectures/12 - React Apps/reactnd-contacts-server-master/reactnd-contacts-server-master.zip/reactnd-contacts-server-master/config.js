exports.port = process.env.PORT || 5001
exports.origin = process.env.ORIGIN || `http://localhost:${exports.port}`
